/**
 * ==========================================================================
 * API SERVICE MODULE - Smart Event Entry Management System
 * ==========================================================================
 * Bridges Google Apps Script Web App API with local Storage fallback.
 * Allows seamless offline/standalone testing on VERCEL and online cloud sync.
 */

const STORAGE_KEYS = {
  SETTINGS: "smart_event_settings",
  EVENTS: "smart_event_events",
  REGISTRATIONS: "smart_event_registrations",
  ATTENDANCE: "smart_event_attendance",
  VOLUNTEERS: "smart_event_volunteers",
  CURRENT_USER: "smart_event_current_user"
};

const ApiService = {
  /**
   * Get Web App API URL from Settings, Global APP_CONFIG, or Vercel Environment Variables
   */
  getApiUrl() {
    const settings = this.getSettings();
    if (settings.webAppUrl && settings.webAppUrl.trim() !== "") {
      return settings.webAppUrl.trim();
    }
    if (typeof window !== "undefined") {
      if (window.APP_CONFIG && window.APP_CONFIG.API_URL && window.APP_CONFIG.API_URL.trim() !== "") {
        return window.APP_CONFIG.API_URL.trim();
      }
      const envUrl = window.VITE_API_URL || 
                     window.NEXT_PUBLIC_API_URL || 
                     window.REACT_APP_API_URL || 
                     window.DATABASE_API_URL || 
                     window.VERCEL_API_URL || 
                     window.API_URL || "";
      if (envUrl && envUrl.trim() !== "") {
        return envUrl.trim();
      }
    }
    return "";
  },

  getSettings() {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const envApiUrl = (typeof window !== "undefined" && window.APP_CONFIG && window.APP_CONFIG.API_URL) ? window.APP_CONFIG.API_URL : "";
    const canonicalSiteUrl = "https://event-management-system-chi-seven.vercel.app";
    const defaults = { webAppUrl: envApiUrl, siteUrl: canonicalSiteUrl, autoSync: true, theme: "dark" };
    if (!data) return defaults;
    const parsed = JSON.parse(data);

    // --- siteUrl sanitization ---
    // siteUrl must only be an origin (scheme+host), never a full URL with query params.
    // Strip any path/query/fragment that could have been saved from a poisoned share link.
    if (parsed.siteUrl) {
      try {
        const su = new URL(parsed.siteUrl);
        // Reject if it looks like a share link (contains ?event=) or is not the production origin
        if (su.searchParams.has("event") || su.searchParams.has("backend") || su.searchParams.has("eventId")) {
          console.warn("[Settings] siteUrl contains event params — resetting to canonical URL:", parsed.siteUrl);
          parsed.siteUrl = canonicalSiteUrl;
        } else {
          parsed.siteUrl = su.origin; // strip path/query/fragment, keep only origin
        }
      } catch (_) {
        parsed.siteUrl = canonicalSiteUrl;
      }
    } else {
      parsed.siteUrl = canonicalSiteUrl;
    }

    // Auto-migrate: replace any old netlify domain cached in localStorage
    if (parsed.siteUrl && parsed.siteUrl.includes("netlify.app")) {
      parsed.siteUrl = canonicalSiteUrl;
    }

    // --- webAppUrl sanitization ---
    // webAppUrl must point to the Google Apps Script exec endpoint.
    // Reject any URL that:
    //   (a) Contains '?event=' or '?eventId=' (it is a share link, not an API URL)
    //   (b) Matches the Vercel site URL (it is the frontend, not the backend)
    //   (c) Does not contain 'script.google.com' (not a valid Apps Script URL)
    //       UNLESS the operator set a custom API URL via environment variable.
    if (parsed.webAppUrl) {
      const wau = parsed.webAppUrl.trim();
      let invalidWebAppUrl = false;
      try {
        const wauParsed = new URL(wau);
        if (
          wauParsed.searchParams.has("event") ||
          wauParsed.searchParams.has("eventId") ||
          wauParsed.searchParams.has("backend") ||
          wau.includes("vercel.app") ||
          wau.includes("netlify.app")
        ) {
          invalidWebAppUrl = true;
        }
      } catch (_) {
        invalidWebAppUrl = true; // not a valid URL at all
      }

      if (invalidWebAppUrl) {
        console.warn("[Settings] webAppUrl appears to be a poisoned share link, not an API URL — clearing it:", wau);
        parsed.webAppUrl = envApiUrl; // fall back to environment variable
      }
    }

    // If no webAppUrl set, use environment variable
    if (!parsed.webAppUrl && envApiUrl) {
      parsed.webAppUrl = envApiUrl;
    }

    return parsed;
  },


  saveSettings(settings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },

  /**
   * Fetch Events
   */
  async getEvents() {
    const apiUrl = this.getApiUrl();
    console.log("[EventSync] getEvents() called. API URL:", apiUrl || "(not configured)");
    if (apiUrl) {
      try {
        const fetchUrl = `${apiUrl}?action=getEvents`;
        console.log("[EventSync] Fetching events from:", fetchUrl);
        const response = await this.fetchWithRetry(fetchUrl);
        console.log("[EventSync] API response status:", response.status, response.statusText);
        const text = await response.text();
        console.log("[EventSync] API raw response (first 500 chars):", text.substring(0, 500));
        try {
          const json = JSON.parse(text);
          if (Array.isArray(json)) {
            console.log("[EventSync] Successfully fetched", json.length, "events from API. IDs:", json.map(e => e.id));
            this.saveLocal(STORAGE_KEYS.EVENTS, json);
            return json;
          } else {
            console.warn("[EventSync] API returned non-array response:", json);
          }
        } catch (parseErr) {
          console.error("[EventSync] Failed to parse API response as JSON:", parseErr);
        }
      } catch (err) {
        console.error("[EventSync] Cloud API fetch FAILED:", err.message || err);
      }
    } else {
      console.warn("[EventSync] No API URL configured. Using localStorage fallback.");
    }
    const localEvents = this.getLocal(STORAGE_KEYS.EVENTS, this.getDefaultEvents());
    console.log("[EventSync] Returning localStorage events. Count:", localEvents.length, "IDs:", localEvents.map(e => e.id));
    return localEvents;
  },

  /**
   * Fetch Single Event Directly from Database by ID
   */
  /** GET with 15s timeout and up to 3 attempts (mobile networks + Apps Script cold starts). */
  async fetchWithRetry(url, attempts = 3) {
    let lastErr;
    for (let i = 0; i < attempts; i++) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 15000);
      try {
        const resp = await fetch(url, { method: "GET", redirect: "follow", signal: ctrl.signal });
        clearTimeout(timer);
        return resp;
      } catch (err) {
        clearTimeout(timer);
        lastErr = err;
        await new Promise(r => setTimeout(r, 800 * (i + 1)));
      }
    }
    throw lastErr;
  },

  async getEventById(eventId) {
    const apiUrl = this.getApiUrl();
    console.log("[EventSync] getEventById() called.", "\n  Event ID:", eventId, "\n  API URL:", apiUrl || "(not configured)");

    if (apiUrl) {
      const fetchUrl = `${apiUrl}?action=getEvent&eventId=${encodeURIComponent(eventId)}`;
      console.log("[EventSync] Fetching event from:", fetchUrl);
      try {
        const response = await this.fetchWithRetry(fetchUrl);
        console.log("[EventSync] getEventById response — Status:", response.status, response.statusText, "| URL:", fetchUrl);

        const text = await response.text();
        console.log("[EventSync] getEventById raw response (first 500 chars):", text.substring(0, 500));

        if (!response.ok) {
          console.error(
            "[EventSync] getEventById HTTP error.",
            "\n  Requested Event ID:", eventId,
            "\n  Fetch URL:", fetchUrl,
            "\n  HTTP Status:", response.status, response.statusText,
            "\n  Response body:", text.substring(0, 300)
          );
          return { status: "error", code: "HTTP_ERROR", message: `Server returned HTTP ${response.status}: ${response.statusText}` };
        }

        try {
          const json = JSON.parse(text);
          if (json && json.status === "success" && json.event) {
            return json.event;
          } else if (json && json.id) {
            return json;
          } else if (Array.isArray(json)) {
            const found = json.find(e => e.id.toUpperCase() === eventId.toUpperCase());
            if (found) return found;
            console.error(
              "[EventSync] getEventById: event ID not found in array response.",
              "\n  Requested Event ID:", eventId,
              "\n  Array length:", json.length,
              "\n  Available IDs:", json.map(e => e.id).join(", ") || "(none)"
            );
          } else {
            console.error(
              "[EventSync] getEventById: unexpected response shape.",
              "\n  Requested Event ID:", eventId,
              "\n  Parsed response:", JSON.stringify(json).substring(0, 200)
            );
          }
          return json;
        } catch (parseErr) {
          console.error(
            "[EventSync] getEventById: failed to parse API response as JSON.",
            "\n  Requested Event ID:", eventId,
            "\n  Fetch URL:", fetchUrl,
            "\n  Parse error:", parseErr.message,
            "\n  Raw response:", text.substring(0, 300)
          );
          const looksLikeGoogleLogin = /accounts\.google\.com|Sign in|<html/i.test(text);
          return { status: "error", code: looksLikeGoogleLogin ? "NOT_PUBLIC" : "PARSE_ERROR", message: "Failed to parse database response." };
        }
      } catch (err) {
        console.error(
          "[EventSync] getEventById: network/fetch error.",
          "\n  Requested Event ID:", eventId,
          "\n  Fetch URL:", fetchUrl,
          "\n  Error:", err.message || err
        );
        return { status: "error", code: "DB_CONNECTION_FAIL", message: "Database connection failed.", detail: (err && err.message) || String(err) };
      }
    } else {
      console.error(
        "[EventSync] getEventById: no API URL configured — cannot reach production database.",
        "\n  Requested Event ID:", eventId,
        "\n  Fix: Set the Google Apps Script Web App URL in Settings or via the API_URL environment variable."
      );
      return { status: "error", code: "NO_API_URL", message: "Database connection failed (API URL not configured)." };
    }
  },
  async registerStudent(studentData) {
    const hallTicket = studentData.hallTicket.toUpperCase();
    const apiUrl = this.getApiUrl();

    // 1. Quick local duplicate check (same device)
    const regs = this.getLocal(STORAGE_KEYS.REGISTRATIONS, []);
    if (regs.some(r => r.eventId === studentData.eventId && r.hallTicket.toUpperCase() === hallTicket)) {
      return { status: "duplicate", message: `Student with Hall Ticket ${hallTicket} is already registered for this event!` };
    }

    // 2. CLOUD FIRST: the server is the single source of truth so that the
    //    admin / volunteer scanner phones can see every registration.
    if (apiUrl) {
      try {
        const resp = await fetch(apiUrl, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify({ action: "registerStudent", data: { ...studentData, hallTicket } })
        });
        const json = JSON.parse(await resp.text());
        if (json.status === "duplicate") return json;
        if (json.status === "success" && json.registrationId) {
          const record = {
            registrationId: json.registrationId,
            eventId: studentData.eventId,
            eventName: studentData.eventName,
            fullName: studentData.fullName,
            hallTicket,
            branch: studentData.branch,
            year: studentData.year,
            section: studentData.section,
            mobile: studentData.mobile,
            email: studentData.email,
            photo: studentData.photo || "",
            qrPayload: json.qrPayload,
            registeredAt: json.registeredAt
          };
          regs.push(record);
          this.saveLocal(STORAGE_KEYS.REGISTRATIONS, regs);
          return { status: "success", message: "Registration successful!", record };
        }
        return { status: "error", message: json.message || "Server rejected the registration. Please try again." };
      } catch (err) {
        console.error("[EventSync] Registration failed:", err);
        return { status: "error", message: "Could not reach the server. Check your internet connection and try again — your registration was NOT saved." };
      }
    }

    // 3. No backend configured: registration only works on this device (demo mode)
    const regId = "REG-" + studentData.eventId.replace("EVT-", "") + "-" + Math.random().toString(36).substr(2, 6).toUpperCase();
    const qrPayload = JSON.stringify({
      regId, eventId: studentData.eventId, ht: hallTicket, name: studentData.fullName,
      branch: studentData.branch, year: studentData.year
    });
    const newRecord = {
      registrationId: regId, eventId: studentData.eventId, eventName: studentData.eventName,
      fullName: studentData.fullName, hallTicket, branch: studentData.branch, year: studentData.year,
      section: studentData.section, mobile: studentData.mobile, email: studentData.email,
      photo: studentData.photo || "", qrPayload, registeredAt: new Date().toISOString()
    };
    regs.push(newRecord);
    this.saveLocal(STORAGE_KEYS.REGISTRATIONS, regs);
    return { status: "success", message: "Registration saved on this device only (no backend configured).", record: newRecord };
  },

  /**
   * Pull registrations + attendance from the cloud into local cache so the
   * dashboard, attendance table, reports and scanner see ALL devices' data.
   */
  async syncFromCloud() {
    const apiUrl = this.getApiUrl();
    if (!apiUrl) return false;
    try {
      const [rRes, aRes] = await Promise.all([
        fetch(`${apiUrl}?action=getRegistrations`, { redirect: "follow" }).then(r => r.json()),
        fetch(`${apiUrl}?action=getAttendance`, { redirect: "follow" }).then(r => r.json())
      ]);
      if (Array.isArray(rRes)) {
        const local = this.getLocal(STORAGE_KEYS.REGISTRATIONS, []);
        const photos = {};
        local.forEach(l => { if (l.photo) photos[l.registrationId] = l.photo; });
        const merged = rRes.map(r => ({
          ...r,
          hallTicket: String(r.hallTicket || "").toUpperCase(),
          photo: photos[r.registrationId] || ""
        }));
        this.saveLocal(STORAGE_KEYS.REGISTRATIONS, merged);
      }
      if (Array.isArray(aRes)) {
        this.saveLocal(STORAGE_KEYS.ATTENDANCE, aRes.map(a => ({ ...a, hallTicket: String(a.hallTicket || "").toUpperCase() })));
      }
      return true;
    } catch (err) {
      console.error("[EventSync] syncFromCloud failed:", err);
      return false;
    }
  },

  /**
   * Mark Attendance
   */
  async markAttendance(data) {
    const apiUrl = this.getApiUrl();
    const attendance = this.getLocal(STORAGE_KEYS.ATTENDANCE, []);
    const ht = data.hallTicket.toUpperCase();

    const record = {
      attendanceId: "ATT-" + Math.random().toString(36).substr(2, 8).toUpperCase(),
      eventId: data.eventId,
      registrationId: data.registrationId || "MANUAL",
      hallTicket: ht,
      fullName: data.fullName,
      branch: data.branch || "N/A",
      status: "VALID",
      scannedBy: data.scannedBy || "Admin",
      scanTimestamp: new Date().toISOString(),
      remarks: data.remarks || "Camera Scan"
    };

    // CLOUD: server is authoritative, so two gates can never admit the same student twice
    if (apiUrl) {
      try {
        const resp = await fetch(apiUrl, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify({ action: "markAttendance", data: record })
        });
        const json = JSON.parse(await resp.text());
        if (json.status === "already_entered") {
          return { status: "already_entered", message: json.message, entryTime: json.entryTime, scannedBy: json.scannedBy };
        }
        if (json.status === "valid") {
          if (json.attendanceId) record.attendanceId = json.attendanceId;
          record.scanTimestamp = json.entryTime || record.scanTimestamp;
          attendance.push(record);
          this.saveLocal(STORAGE_KEYS.ATTENDANCE, attendance);
          return { status: "valid", message: "Entry Authorized!", record };
        }
        return { status: "error", message: json.message || "Server error" };
      } catch (err) {
        console.error("[EventSync] markAttendance failed:", err);
        return { status: "error", message: "No internet / server unreachable. Entry NOT recorded — scan again when online." };
      }
    }

    // LOCAL-ONLY (demo mode)
    const existing = attendance.find(a => a.eventId === data.eventId && a.hallTicket.toUpperCase() === ht && a.status === "VALID");
    if (existing) {
      return { status: "already_entered", message: "Student has already entered the venue!", entryTime: existing.scanTimestamp, scannedBy: existing.scannedBy };
    }
    attendance.push(record);
    this.saveLocal(STORAGE_KEYS.ATTENDANCE, attendance);
    return { status: "valid", message: "Entry Authorized!", record };
  },

  async syncCreateEvent(eventData) {
    const apiUrl = this.getApiUrl();
    console.log("[EventSync] syncCreateEvent called. API URL:", apiUrl || "(not configured)", "Event ID:", eventData.id);
    if (apiUrl) {
      try {
        const resp = await fetch(apiUrl, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify({ action: "createEvent", data: eventData })
        });
        console.log("[EventSync] syncCreateEvent response status:", resp.status);
        const text = await resp.text();
        console.log("[EventSync] syncCreateEvent response body:", text.substring(0, 300));
        try {
          const json = JSON.parse(text);
          if (json && (json.status === "success" || json.success)) {
            return { success: true, message: "Event saved to production cloud database." };
          }
        } catch (_) {}
        return { success: true, message: "Synced to cloud database." };
      } catch (err) {
        console.error("[EventSync] syncCreateEvent FAILED:", err.message || err);
        return { success: false, error: err.message || "Failed to reach production database." };
      }
    } else {
      console.warn("[EventSync] syncCreateEvent skipped: no API URL configured.");
      return { success: false, error: "No production Web App API URL configured in Settings or Environment Variables." };
    }
  },

  async syncUpdateEvent(eventData) {
    const apiUrl = this.getApiUrl();
    console.log("[EventSync] syncUpdateEvent called. API URL:", apiUrl || "(not configured)", "Event ID:", eventData.id);
    if (apiUrl) {
      try {
        const resp = await fetch(apiUrl, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify({ action: "updateEvent", data: eventData })
        });
        console.log("[EventSync] syncUpdateEvent response status:", resp.status);
        return resp;
      } catch (err) {
        console.error("[EventSync] syncUpdateEvent FAILED:", err.message || err);
      }
    }
    return Promise.resolve();
  },

  async syncDeleteEvent(eventId) {
    const apiUrl = this.getApiUrl();
    console.log("[EventSync] syncDeleteEvent called. API URL:", apiUrl || "(not configured)", "Event ID:", eventId);
    if (apiUrl) {
      try {
        const resp = await fetch(apiUrl, {
          method: "POST",
          headers: { "Content-Type": "text/plain" },
          body: JSON.stringify({ action: "deleteEvent", eventId: eventId })
        });
        console.log("[EventSync] syncDeleteEvent response status:", resp.status);
        return resp;
      } catch (err) {
        console.error("[EventSync] syncDeleteEvent FAILED:", err.message || err);
      }
    }
    return Promise.resolve();
  },

  /**
   * Storage Helpers
   */
  getLocal(key, defaultValue) {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : defaultValue;
  },

  saveLocal(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },

  /**
   * Default Seed Data
   */
  getDefaultEvents() {
    return [];
  }
};